const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getMessaging } = require("firebase-admin/messaging");
const { getFirestore } = require("firebase-admin/firestore");

initializeApp();

exports.notifyNewBooking = onDocumentCreated("bookings/{bookingId}", async (event) => {
  const booking = event.data?.data();
  if (!booking) return;

  const db = getFirestore();
  const admins = await db.collection("users").where("role", "==", "admin").get();

  const tokens = [];
  admins.forEach((doc) => {
    const data = doc.data();
    const list = data.fcmTokens || [];
    tokens.push(...list);
  });

  if (!tokens.length) return;

  await getMessaging().sendEachForMulticast({
    tokens: [...new Set(tokens)],
    notification: {
      title: "حجز جديد - عدسة سبها",
      body: `${booking.adTitle || "إعلان"} - ${booking.total || 0} د.ل`,
    },
    data: {
      type: "booking",
      bookingId: event.params.bookingId,
    },
  });
});

exports.notifyBookingStatus = onDocumentUpdated("bookings/{bookingId}", async (event) => {
  const before = event.data?.before.data();
  const after = event.data?.after.data();
  if (!before || !after || before.status === after.status) return;

  const userId = after.userId;
  if (!userId) return;

  const db = getFirestore();
  const userDoc = await db.collection("users").doc(userId).get();
  const tokens = userDoc.data()?.fcmTokens || [];
  if (!tokens.length) return;

  await getMessaging().sendEachForMulticast({
    tokens: [...new Set(tokens)],
    notification: {
      title: "تحديث الحجز - عدسة سبها",
      body: `حالة الحجز أصبحت: ${after.status}`,
    },
    data: {
      type: "booking_status",
      bookingId: event.params.bookingId,
    },
  });
});
