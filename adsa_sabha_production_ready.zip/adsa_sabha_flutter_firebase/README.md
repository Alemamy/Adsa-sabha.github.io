# عدسة سبها - Flutter + Firebase (المرحلة 2)

هذه النسخة تنقل المشروع من Prototype محلي إلى بنية جاهزة لـ Firebase.

## تم تنفيذ

- Firebase Core.
- Firebase Authentication بالبريد وكلمة المرور.
- Firestore للمستخدمين والإعلانات والعروض والحجوزات.
- Cloud Storage لرفع صور الإعلانات.
- Firebase Cloud Messaging (FCM) كبنية للإشعارات.
- لوحة مستخدم رئيسي Admin.
- تعديل الأسعار من قاعدة البيانات.
- إضافة/تعديل الإعلانات.
- رفع صورة الإعلان.
- إضافة العروض والخصومات.
- تشغيل/إيقاف الإعلانات والعروض.
- الحجوزات وتغيير حالتها من لوحة الإدارة.
- قواعد Firestore وStorage مبدئية للحماية.
- Cloud Functions لإرسال إشعار عند إنشاء حجز أو تغيير حالته.
- وضع Demo يعمل بدون Firebase حتى يتم إعداد المشروع.

## إعداد الإنتاج

تم تجهيز نسخة Android للإنتاج باستخدام مشروع Firebase `adsa-sabha` ومعرّف التطبيق `com.adsa.sabha`. تم تعطيل مسار Demo وحساب `admin / 1234` من التطبيق.

### مطلوب مرة واحدة في Firebase Console

1. تفعيل Authentication → Sign-in method → Email/Password.
2. إنشاء Firestore Database.
3. تفعيل Storage.
4. نشر `firestore.rules` و`storage.rules`.
5. إنشاء أول حساب من التطبيق، ثم منح الحساب دور `admin` في `users/{uid}` من لوحة Firebase.
6. إذا أردت إشعارات الخلفية، نشر Cloud Functions الموجودة داخل `functions/`.

### بناء Android

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

يوجد أيضاً GitHub Actions في `.github/workflows/build-release-apk.yml` لبناء APK تلقائياً ورفعه كـ Artifact.

> ملاحظة النشر الرسمي على Google Play: نسخة Release الحالية تستخدم توقيع debug مؤقتاً حتى لا يتم اختراع/تضمين مفتاح توقيع خاص بك. للنشر في Google Play يجب إنشاء مفتاح upload/release خاص بك وإضافته إلى إعدادات البناء بشكل آمن.

## بوابة الدفع

خيار البطاقة الموجود في الواجهة ليس بوابة دفع حقيقية؛ تفعيل الدفع الإلكتروني يحتاج مزود دفع مناسب لليبيا ومفاتيح API من حسابك.
