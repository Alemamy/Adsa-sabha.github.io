import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';
import '../app_config.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String?> uploadAdImage({
    required String adId,
    required Uint8List bytes,
    required String extension,
  }) async {

    final ref = _storage.ref().child('ads/$adId/main.$extension');
    await ref.putData(
      bytes,
      SettableMetadata(contentType: 'image/$extension'),
    );
    return ref.getDownloadURL();
  }
}
