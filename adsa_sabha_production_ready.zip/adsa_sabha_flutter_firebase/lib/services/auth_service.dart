import 'package:firebase_auth/firebase_auth.dart';
import '../models.dart';
import 'firestore_service.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? get currentUser => _auth.currentUser;

  Future<UserProfile> signIn({
    required String email,
    required String password,
    required FirestoreService db,
  }) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = cred.user!;
    return await db.getUserProfile(user.uid) ??
        UserProfile(
          uid: user.uid,
          name: user.displayName ?? '',
          email: user.email ?? email,
          role: 'user',
        );
  }

  Future<UserProfile> register({
    required String name,
    required String email,
    required String password,
    required FirestoreService db,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = cred.user!;
    await user.updateDisplayName(name);

    final profile = UserProfile(
      uid: user.uid,
      name: name,
      email: user.email ?? email,
      role: 'user',
    );
    await db.createUserProfile(profile);
    return profile;
  }

  Future<void> signOut() => _auth.signOut();
}
