import 'package:firebase_messaging/firebase_messaging.dart';
import '../app_config.dart';

class NotificationService {
  static Future<String?> token() async {
    return FirebaseMessaging.instance.getToken();
  }

  static Future<void> initialize() async {

    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );


    FirebaseMessaging.onMessage.listen((message) {
      // TODO: اربط هنا local notification إذا أردت إشعاراً مرئياً
      // أثناء فتح التطبيق.
    });
  }
}
