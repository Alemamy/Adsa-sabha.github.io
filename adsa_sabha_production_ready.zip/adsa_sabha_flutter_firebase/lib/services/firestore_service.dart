import 'package:cloud_firestore/cloud_firestore.dart';
import '../app_config.dart';
import '../models.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<UserProfile?> getUserProfile(String uid) async {
    final snap = await _db.collection('users').doc(uid).get();
    if (!snap.exists) return null;
    return UserProfile.fromMap(uid, snap.data()!);
  }

  Future<void> createUserProfile(UserProfile profile) async {
    await _db.collection('users').doc(profile.uid).set(profile.toMap());
  }

  Future<void> saveFcmToken(String uid, String token) async {
    if (token.isEmpty) return;
    await _db.collection('users').doc(uid).set({
      'fcmTokens': FieldValue.arrayUnion([token]),
    }, SetOptions(merge: true));
  }

  Stream<List<AdItem>> adsStream({bool activeOnly = true}) {

    Query<Map<String, dynamic>> q = _db.collection('ads').orderBy('createdAt', descending: true);
    if (activeOnly) q = q.where('active', isEqualTo: true);

    return q.snapshots().map(
          (s) => s.docs.map((d) => AdItem.fromMap(d.id, d.data())).toList(),
        );
  }

  Stream<List<AdItem>> allAdsStream() {
    return _db.collection('ads').orderBy('createdAt', descending: true).snapshots().map(
          (s) => s.docs.map((d) => AdItem.fromMap(d.id, d.data())).toList(),
        );
  }

  Future<String> createAd(AdItem ad) async {
    final ref = await _db.collection('ads').add({
      ...ad.toMap(),
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> updateAd(AdItem ad) async {
    await _db.collection('ads').doc(ad.id).update(ad.toMap());
  }

  Future<void> deleteAd(String id) async {
    await _db.collection('ads').doc(id).delete();
  }

  Stream<List<OfferItem>> offersStream({bool activeOnly = true}) {
    Query<Map<String, dynamic>> q = _db.collection('offers').orderBy('createdAt', descending: true);
    if (activeOnly) q = q.where('active', isEqualTo: true);

    return q.snapshots().map(
          (s) => s.docs.map((d) => OfferItem.fromMap(d.id, d.data())).toList(),
        );
  }

  Stream<List<OfferItem>> allOffersStream() {
    return _db.collection('offers').orderBy('createdAt', descending: true).snapshots().map(
          (s) => s.docs.map((d) => OfferItem.fromMap(d.id, d.data())).toList(),
        );
  }

  Future<String> createOffer(OfferItem offer) async {
    final ref = await _db.collection('offers').add({
      ...offer.toMap(),
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> updateOffer(OfferItem offer) async {
    await _db.collection('offers').doc(offer.id).update(offer.toMap());
  }

  Future<String> createBooking(BookingItem booking) async {
    final ref = await _db.collection('bookings').add(booking.toMap());
    return ref.id;
  }

  Stream<List<BookingItem>> userBookings(String uid) {
    return _db
        .collection('bookings')
        .where('userId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => BookingItem.fromMap(d.id, d.data())).toList());
  }

  Stream<List<BookingItem>> allBookings() {
    return _db
        .collection('bookings')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => BookingItem.fromMap(d.id, d.data())).toList());
  }

  Future<void> updateBookingStatus(String id, String status) async {
    await _db.collection('bookings').doc(id).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
