import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import 'app_config.dart';
import 'models.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'services/storage_service.dart';

class Logo extends StatelessWidget {
  final double size;
  const Logo({super.key, this.size = 120});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white12),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset('assets/sabha_lens_logo.png', fit: BoxFit.cover),
    );
  }
}

class LoginScreen extends StatefulWidget {
  final AuthService auth;
  final FirestoreService db;
  final void Function(UserProfile) onLoggedIn;

  const LoginScreen({
    super.key,
    required this.auth,
    required this.db,
    required this.onLoggedIn,
  });

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);
    try {
      final p = await widget.auth.signIn(
        email: email.text,
        password: password.text,
        db: widget.db,
      );
      widget.onLoggedIn(p);
    } catch (e) {
      _error('تعذر تسجيل الدخول: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _error(String text) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(text)),
      );

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(24),
              children: [
                const SizedBox(height: 35),
                const Center(child: Logo(size: 145)),
                const SizedBox(height: 16),
                const Center(
                  child: Text('عدسة سبها', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
                ),
                const Center(
                  child: Text('SABHA LENS', style: TextStyle(color: AppTheme.gold, letterSpacing: 5)),
                ),
                const SizedBox(height: 8),
                const Center(child: Text('إعلاناتك .. في المكان المناسب', style: TextStyle(color: AppTheme.muted))),
                const SizedBox(height: 35),
                TextField(
                  controller: email,
                  decoration: const InputDecoration(
                    labelText: 'البريد الإلكتروني / اسم المستخدم',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'كلمة المرور',
                    prefixIcon: Icon(Icons.lock_outline),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  height: 54,
                  child: FilledButton(
                    onPressed: loading ? null : login,
                    style: FilledButton.styleFrom(
                      backgroundColor: AppTheme.gold,
                      foregroundColor: Colors.black,
                    ),
                    child: loading
                        ? const CircularProgressIndicator(color: Colors.black)
                        : const Text('تسجيل الدخول', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  ),
                ),
                const SizedBox(height: 14),
                OutlinedButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => RegisterScreen(auth: widget.auth, db: widget.db, onLoggedIn: widget.onLoggedIn),
                    ),
                  ),
                  child: const Text('إنشاء حساب جديد'),
                ),
              ],
            ),
          ),
        ),
      );
}

class RegisterScreen extends StatefulWidget {
  final AuthService auth;
  final FirestoreService db;
  final void Function(UserProfile) onLoggedIn;

  const RegisterScreen({
    super.key,
    required this.auth,
    required this.db,
    required this.onLoggedIn,
  });

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> register() async {
    setState(() => loading = true);
    try {
      final p = await widget.auth.register(
        name: name.text,
        email: email.text,
        password: password.text,
        db: widget.db,
      );
      if (mounted) Navigator.pop(context);
      widget.onLoggedIn(p);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء الحساب: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('إنشاء حساب')),
          body: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
              const SizedBox(height: 12),
              TextField(controller: email, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
              const SizedBox(height: 12),
              TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور')),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: loading ? null : register,
                style: FilledButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
                child: const Text('إنشاء الحساب'),
              ),
            ],
          ),
        ),
      );
}

class UserDashboard extends StatefulWidget {
  final FirestoreService db;
  final UserProfile profile;
  final Future<void> Function() onLogout;

  const UserDashboard({
    super.key,
    required this.db,
    required this.profile,
    required this.onLogout,
  });

  @override
  State<UserDashboard> createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> {
  int tab = 0;

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('عدسة سبها', style: TextStyle(fontWeight: FontWeight.w900)),
            actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))],
          ),
          body: IndexedStack(
            index: tab,
            children: [
              _home(),
              _ads(),
              _bookings(),
              _profile(),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            backgroundColor: AppTheme.surface,
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
              NavigationDestination(icon: Icon(Icons.campaign_outlined), label: 'الإعلانات'),
              NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'حجوزاتي'),
              NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
            ],
          ),
        ),
      );

  Widget _home() => StreamBuilder<List<AdItem>>(
        stream: widget.db.adsStream(),
        builder: (context, snap) {
          final ads = snap.data ?? const <AdItem>[];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: AppTheme.gold.withOpacity(.35)),
                ),
                child: const Row(
                  children: [
                    Expanded(
                      child: Text(
                        'إعلانك يصل إلى جمهورك\nاختر المكان والمدة واحجز بسهولة.',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                      ),
                    ),
                    Logo(size: 80),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const Text('الإعلانات المتاحة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              if (ads.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(25),
                  child: Center(child: Text('لا توجد إعلانات حالياً', style: TextStyle(color: AppTheme.muted))),
                ),
              ...ads.map((ad) => AdCard(ad: ad)),
              const SizedBox(height: 15),
              StreamBuilder<List<OfferItem>>(
                stream: widget.db.offersStream(),
                builder: (_, s) {
                  final offers = s.data ?? const <OfferItem>[];
                  if (offers.isEmpty) return const SizedBox.shrink();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('العروض', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      ...offers.map(
                        (o) => Card(
                          color: AppTheme.surface2,
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: AppTheme.gold,
                              foregroundColor: Colors.black,
                              child: Text('${o.discount}%'),
                            ),
                            title: Text(o.title),
                            subtitle: Text(o.details, style: const TextStyle(color: AppTheme.muted)),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          );
        },
      );

  Widget _ads() => StreamBuilder<List<AdItem>>(
        stream: widget.db.adsStream(),
        builder: (_, s) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('الإعلانات', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            ...(s.data ?? const <AdItem>[]).map((a) => AdCard(ad: a)),
          ],
        ),
      );

  Widget _bookings() => StreamBuilder<List<BookingItem>>(
        stream: widget.db.userBookings(widget.profile.uid),
        builder: (_, s) {
          final bookings = s.data ?? const <BookingItem>[];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('حجوزاتي', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              if (bookings.isEmpty) const Text('لا توجد حجوزات حتى الآن', style: TextStyle(color: AppTheme.muted)),
              ...bookings.map(
                (b) => Card(
                  color: AppTheme.surface,
                  child: ListTile(
                    title: Text(b.adTitle),
                    subtitle: Text('${b.days} يوم • ${b.total.toStringAsFixed(0)} ${AppConfig.currency}'),
                    trailing: Chip(label: Text(b.status)),
                  ),
                ),
              ),
            ],
          );
        },
      );

  Widget _profile() => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Center(child: Logo(size: 100)),
          const SizedBox(height: 12),
          Center(child: Text(widget.profile.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
          Center(child: Text(widget.profile.email, style: const TextStyle(color: AppTheme.muted))),
          const SizedBox(height: 25),
          ListTile(leading: const Icon(Icons.person_outline), title: const Text('معلومات الحساب')),
          ListTile(leading: const Icon(Icons.support_agent), title: const Text('الدعم والمساعدة')),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)),
            onTap: widget.onLogout,
          ),
        ],
      );
}

class AdCard extends StatelessWidget {
  final AdItem ad;
  const AdCard({super.key, required this.ad});

  @override
  Widget build(BuildContext context) => Card(
        color: AppTheme.surface,
        margin: const EdgeInsets.only(bottom: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: Colors.white10),
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.all(10),
          leading: SizedBox(
            width: 70,
            height: 70,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: ad.imageUrl.isEmpty
                  ? Image.asset('assets/sabha_lens_logo.png', fit: BoxFit.cover)
                  : Image.network(ad.imageUrl, fit: BoxFit.cover),
            ),
          ),
          title: Text(ad.title, style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text(ad.location, style: const TextStyle(color: AppTheme.muted)),
          trailing: Text(
            '${ad.price.toStringAsFixed(0)} ${AppConfig.currency}/${ad.unit}',
            style: const TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w900),
          ),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AdDetailsScreen(ad: ad, db: widget.db, profile: widget.profile)),
          ),
        ),
      );
}

class AdDetailsScreen extends StatelessWidget {
  final AdItem ad;
  const AdDetailsScreen({super.key, required this.ad, required this.db, required this.profile});

  final FirestoreService db;
  final UserProfile profile;

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('تفاصيل الإعلان')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: ad.imageUrl.isEmpty
                    ? Image.asset('assets/sabha_lens_logo.png', height: 240, fit: BoxFit.cover)
                    : Image.network(ad.imageUrl, height: 240, fit: BoxFit.cover),
              ),
              const SizedBox(height: 15),
              Text(ad.title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              Text(ad.location, style: const TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 15),
              Text(
                '${ad.price.toStringAsFixed(0)} ${AppConfig.currency} / ${ad.unit}',
                style: const TextStyle(color: AppTheme.gold, fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 20),
              const Text('الحجز', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              FilledButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => BookingScreen(ad: ad, db: db, profile: profile)),
                ),
                style: FilledButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
                child: const Text('ابدأ الحجز'),
              ),
            ],
          ),
        ),
      );
}

class BookingScreen extends StatefulWidget {
  final AdItem ad;
  final FirestoreService db;
  final UserProfile profile;
  const BookingScreen({super.key, required this.ad, required this.db, required this.profile});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  DateTime start = DateTime.now();
  int days = 1;
  String payment = 'cash';
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    final end = start.add(Duration(days: days - 1));
    final total = widget.ad.price * days;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('حجز الإعلان')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(widget.ad.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 18),
            ListTile(
              tileColor: AppTheme.surface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              title: const Text('تاريخ البداية'),
              subtitle: Text(DateFormat('yyyy-MM-dd').format(start)),
              trailing: const Icon(Icons.calendar_month, color: AppTheme.gold),
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                  initialDate: start,
                );
                if (d != null) setState(() => start = d);
              },
            ),
            const SizedBox(height: 14),
            const Text('مدة الحجز', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [1, 3, 7, 14, 30].map(
                (d) => ChoiceChip(
                  label: Text('$d يوم'),
                  selected: days == d,
                  selectedColor: AppTheme.gold,
                  labelStyle: TextStyle(color: days == d ? Colors.black : AppTheme.white),
                  onSelected: (_) => setState(() => days = d),
                ),
              ).toList(),
            ),
            const SizedBox(height: 15),
            DropdownButtonFormField<String>(
              initialValue: payment,
              decoration: const InputDecoration(labelText: 'طريقة الدفع'),
              items: const [
                DropdownMenuItem(value: 'cash', child: Text('الدفع عند الاستلام')),
                DropdownMenuItem(value: 'bank', child: Text('تحويل مصرفي')),
                DropdownMenuItem(value: 'card', child: Text('بطاقة - ربط بوابة الدفع لاحقاً')),
              ],
              onChanged: (v) => setState(() => payment = v ?? 'cash'),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(18)),
              child: Column(
                children: [
                  _sum('من', DateFormat('yyyy-MM-dd').format(start)),
                  _sum('إلى', DateFormat('yyyy-MM-dd').format(end)),
                  _sum('المدة', '$days يوم'),
                  const Divider(color: Colors.white12),
                  _sum('الإجمالي', '${total.toStringAsFixed(0)} ${AppConfig.currency}', strong: true),
                ],
              ),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: loading ? null : () => _book(total, end),
              style: FilledButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
              child: loading ? const CircularProgressIndicator(color: Colors.black) : const Text('تأكيد الحجز'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sum(String a, String b, {bool strong = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(a, style: const TextStyle(color: AppTheme.muted)),
            Text(b, style: TextStyle(color: strong ? AppTheme.gold : AppTheme.white, fontWeight: FontWeight.bold)),
          ],
        ),
      );

  Future<void> _book(double total, DateTime end) async {
    setState(() => loading = true);
    try {
      final booking = BookingItem(
        id: '',
        userId: widget.profile.uid,
        adId: widget.ad.id,
        adTitle: widget.ad.title,
        startDate: start,
        endDate: end,
        days: days,
        total: total,
        paymentMethod: payment,
        status: 'pending',
      );
      await widget.db.createBooking(booking);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إرسال الحجز بنجاح، بانتظار تأكيد الإدارة.')),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر إنشاء الحجز: $e')),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }
}

class AdminDashboard extends StatefulWidget {
  final FirestoreService db;
  final StorageService storage;
  final UserProfile profile;
  final Future<void> Function() onLogout;

  const AdminDashboard({
    super.key,
    required this.db,
    required this.storage,
    required this.profile,
    required this.onLogout,
  });

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int tab = 0;

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('لوحة تحكم عدسة سبها', style: TextStyle(fontWeight: FontWeight.w900)),
            actions: [
              IconButton(onPressed: _addAd, icon: const Icon(Icons.add_business)),
              IconButton(onPressed: _addOffer, icon: const Icon(Icons.local_offer_outlined)),
            ],
          ),
          body: IndexedStack(
            index: tab,
            children: [
              _dashboard(),
              _ads(),
              _offers(),
              _bookings(),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            backgroundColor: AppTheme.surface,
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'),
              NavigationDestination(icon: Icon(Icons.campaign_outlined), label: 'الإعلانات'),
              NavigationDestination(icon: Icon(Icons.local_offer_outlined), label: 'العروض'),
              NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'الحجوزات'),
            ],
          ),
        ),
      );

  Widget _dashboard() => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('المستخدم الرئيسي', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const Text('إدارة الأسعار والإعلانات والعروض والحجوزات', style: TextStyle(color: AppTheme.muted)),
          const SizedBox(height: 20),
          StreamBuilder<List<AdItem>>(
            stream: widget.db.allAdsStream(),
            builder: (_, s) => _statCard('الإعلانات', '${s.data?.length ?? 0}', Icons.campaign),
          ),
          StreamBuilder<List<OfferItem>>(
            stream: widget.db.allOffersStream(),
            builder: (_, s) => _statCard('العروض', '${s.data?.length ?? 0}', Icons.local_offer),
          ),
          StreamBuilder<List<BookingItem>>(
            stream: widget.db.allBookings(),
            builder: (_, s) => _statCard('الحجوزات', '${s.data?.length ?? 0}', Icons.calendar_month),
          ),
          const SizedBox(height: 20),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)),
            onTap: widget.onLogout,
          ),
        ],
      );

  Widget _statCard(String label, String value, IconData icon) => Card(
        color: AppTheme.surface,
        child: ListTile(
          leading: const Icon(Icons.circle, color: AppTheme.gold),
          title: Text(label),
          trailing: Text(value, style: const TextStyle(color: AppTheme.gold, fontSize: 24, fontWeight: FontWeight.w900)),
        ),
      );

  Widget _ads() => StreamBuilder<List<AdItem>>(
        stream: widget.db.allAdsStream(),
        builder: (_, s) {
          final ads = s.data ?? const <AdItem>[];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('إدارة الإعلانات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  FilledButton.icon(
                    onPressed: _addAd,
                    style: FilledButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
                    icon: const Icon(Icons.add),
                    label: const Text('إضافة'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ...ads.map(
                (a) => Card(
                  color: AppTheme.surface,
                  child: ListTile(
                    title: Text(a.title),
                    subtitle: Text('${a.type} • ${a.price.toStringAsFixed(0)} ${AppConfig.currency}/${a.unit}'),
                    trailing: IconButton(icon: const Icon(Icons.edit, color: AppTheme.gold), onPressed: () => _editAd(a)),
                  ),
                ),
              ),
            ],
          );
        },
      );

  Widget _offers() => StreamBuilder<List<OfferItem>>(
        stream: widget.db.allOffersStream(),
        builder: (_, s) {
          final offers = s.data ?? const <OfferItem>[];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('إدارة العروض', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  FilledButton.icon(
                    onPressed: _addOffer,
                    style: FilledButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
                    icon: const Icon(Icons.add),
                    label: const Text('إضافة'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ...offers.map(
                (o) => Card(
                  color: AppTheme.surface,
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppTheme.gold,
                      foregroundColor: Colors.black,
                      child: Text('${o.discount}%'),
                    ),
                    title: Text(o.title),
                    subtitle: Text(o.details),
                  ),
                ),
              ),
            ],
          );
        },
      );

  Widget _bookings() => StreamBuilder<List<BookingItem>>(
        stream: widget.db.allBookings(),
        builder: (_, s) {
          final bookings = s.data ?? const <BookingItem>[];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('الحجوزات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              ...bookings.map(
                (b) => Card(
                  color: AppTheme.surface,
                  child: ListTile(
                    title: Text(b.adTitle),
                    subtitle: Text('${b.days} يوم • ${b.total.toStringAsFixed(0)} ${AppConfig.currency} • ${b.status}'),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) => widget.db.updateBookingStatus(b.id, v),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'approved', child: Text('مقبول')),
                        PopupMenuItem(value: 'rejected', child: Text('مرفوض')),
                        PopupMenuItem(value: 'completed', child: Text('مكتمل')),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      );

  Future<void> _addAd() async {
    final result = await showDialog<_AdFormResult>(
      context: context,
      builder: (_) => const AdFormDialog(),
    );
    if (result == null) return;

    final id = await widget.db.createAd(
      AdItem(
        id: '',
        title: result.title,
        type: result.type,
        price: result.price,
        unit: 'يوم',
        location: result.location,
        imageUrl: '',
        active: true,
      ),
    );

    if (result.bytes != null) {
      final url = await widget.storage.uploadAdImage(
        adId: id,
        bytes: result.bytes!,
        extension: result.extension,
      );
      if (url != null) {
        await widget.db.updateAd(
          AdItem(
            id: id,
            title: result.title,
            type: result.type,
            price: result.price,
            unit: 'يوم',
            location: result.location,
            imageUrl: url,
            active: true,
          ),
        );
      }
    }
  }

  Future<void> _editAd(AdItem ad) async {
    final result = await showDialog<_AdFormResult>(
      context: context,
      builder: (_) => AdFormDialog(initial: ad),
    );
    if (result == null) return;

    String imageUrl = ad.imageUrl;
    if (result.bytes != null) {
      imageUrl = await widget.storage.uploadAdImage(
            adId: ad.id,
            bytes: result.bytes!,
            extension: result.extension,
          ) ??
          imageUrl;
    }

    await widget.db.updateAd(
      AdItem(
        id: ad.id,
        title: result.title,
        type: result.type,
        price: result.price,
        unit: ad.unit,
        location: result.location,
        imageUrl: imageUrl,
        active: ad.active,
      ),
    );
  }

  Future<void> _addOffer() async {
    final result = await showDialog<_OfferFormResult>(
      context: context,
      builder: (_) => const OfferFormDialog(),
    );
    if (result == null) return;

    await widget.db.createOffer(
      OfferItem(
        id: '',
        title: result.title,
        details: result.details,
        discount: result.discount,
        active: true,
      ),
    );
  }
}

class _AdFormResult {
  final String title;
  final String type;
  final double price;
  final String location;
  final Uint8List? bytes;
  final String extension;

  const _AdFormResult({
    required this.title,
    required this.type,
    required this.price,
    required this.location,
    this.bytes,
    this.extension = 'jpg',
  });
}

class AdFormDialog extends StatefulWidget {
  final AdItem? initial;
  const AdFormDialog({super.key, this.initial});

  @override
  State<AdFormDialog> createState() => _AdFormDialogState();
}

class _AdFormDialogState extends State<AdFormDialog> {
  late final TextEditingController title;
  late final TextEditingController type;
  late final TextEditingController price;
  late final TextEditingController location;
  Uint8List? bytes;
  String extension = 'jpg';

  @override
  void initState() {
    super.initState();
    final a = widget.initial;
    title = TextEditingController(text: a?.title ?? '');
    type = TextEditingController(text: a?.type ?? 'لوحات إعلانية');
    price = TextEditingController(text: a?.price.toStringAsFixed(0) ?? '');
    location = TextEditingController(text: a?.location ?? 'سبها');
  }

  Future<void> pickImage() async {
    final file = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file == null) return;
    bytes = await file.readAsBytes();
    extension = file.name.contains('.') ? file.name.split('.').last.toLowerCase() : 'jpg';
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          backgroundColor: AppTheme.surface2,
          title: Text(widget.initial == null ? 'إضافة إعلان' : 'تعديل الإعلان'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: title, decoration: const InputDecoration(labelText: 'اسم الإعلان')),
                const SizedBox(height: 10),
                TextField(controller: type, decoration: const InputDecoration(labelText: 'نوع الإعلان')),
                const SizedBox(height: 10),
                TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر / يوم')),
                const SizedBox(height: 10),
                TextField(controller: location, decoration: const InputDecoration(labelText: 'الموقع')),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: pickImage,
                  icon: const Icon(Icons.image_outlined, color: AppTheme.gold),
                  label: Text(bytes == null ? 'اختيار صورة' : 'تم اختيار الصورة'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
              onPressed: () => Navigator.pop(
                context,
                _AdFormResult(
                  title: title.text.trim(),
                  type: type.text.trim(),
                  price: double.tryParse(price.text) ?? 0,
                  location: location.text.trim(),
                  bytes: bytes,
                  extension: extension,
                ),
              ),
              child: const Text('حفظ'),
            ),
          ],
        ),
      );
}

class _OfferFormResult {
  final String title;
  final String details;
  final int discount;
  const _OfferFormResult(this.title, this.details, this.discount);
}

class OfferFormDialog extends StatefulWidget {
  const OfferFormDialog({super.key});

  @override
  State<OfferFormDialog> createState() => _OfferFormDialogState();
}

class _OfferFormDialogState extends State<OfferFormDialog> {
  final title = TextEditingController();
  final details = TextEditingController();
  final discount = TextEditingController();

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          backgroundColor: AppTheme.surface2,
          title: const Text('إضافة عرض'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان العرض')),
              const SizedBox(height: 10),
              TextField(controller: details, decoration: const InputDecoration(labelText: 'تفاصيل العرض')),
              const SizedBox(height: 10),
              TextField(controller: discount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الخصم %')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppTheme.gold, foregroundColor: Colors.black),
              onPressed: () => Navigator.pop(
                context,
                _OfferFormResult(
                  title.text.trim(),
                  details.text.trim(),
                  int.tryParse(discount.text) ?? 0,
                ),
              ),
              child: const Text('حفظ'),
            ),
          ],
        ),
      );
}
