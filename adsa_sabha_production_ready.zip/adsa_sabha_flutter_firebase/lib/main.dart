import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'firebase_options.dart';
import 'models.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'services/notification_service.dart';
import 'services/storage_service.dart';
import 'screens.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await NotificationService.initialize();

  runApp(const SabhaLensApp());
}

class SabhaLensApp extends StatelessWidget {
  const SabhaLensApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'عدسة سبها',
      theme: AppTheme.theme,
      home: const AppRoot(),
    );
  }
}

class AppRoot extends StatefulWidget {
  const AppRoot({super.key});

  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  final auth = AuthService();
  final db = FirestoreService();
  final storage = StorageService();

  UserProfile? profile;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final user = auth.currentUser;
    if (user == null) {
      setState(() => loading = false);
      return;
    }

    profile = await db.getUserProfile(user.uid);
    if (profile != null) {
      await _saveFcmToken(profile!);
    }
    setState(() => loading = false);
  }

  void loggedIn(UserProfile p) {
    setState(() => profile = p);
    _saveFcmToken(p);
  }

  Future<void> _saveFcmToken(UserProfile p) async {
    final token = await NotificationService.token();
    if (token != null && token.isNotEmpty) {
      await db.saveFcmToken(p.uid, token);
    }
  }

  void loggedOut() {
    setState(() => profile = null);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        backgroundColor: AppTheme.bg,
        body: Center(child: CircularProgressIndicator(color: AppTheme.gold)),
      );
    }

    if (profile == null) {
      return LoginScreen(
        auth: auth,
        db: db,
        onLoggedIn: loggedIn,
      );
    }

    if (profile!.isAdmin) {
      return AdminDashboard(
        db: db,
        storage: storage,
        profile: profile!,
        onLogout: () async {
          await auth.signOut();
          loggedOut();
        },
      );
    }

    return UserDashboard(
      db: db,
      profile: profile!,
      onLogout: () async {
        await auth.signOut();
        loggedOut();
      },
    );
  }
}

class AppTheme {
  static const bg = Color(0xFF050505);
  static const surface = Color(0xFF101419);
  static const surface2 = Color(0xFF171C22);
  static const gold = Color(0xFFFFC928);
  static const white = Color(0xFFF6F6F6);
  static const muted = Color(0xFF9AA3AD);

  static ThemeData get theme => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: Brightness.dark,
        ),
        fontFamily: 'Arial',
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Colors.white10),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: gold),
          ),
          hintStyle: const TextStyle(color: muted),
        ),
      );
}
