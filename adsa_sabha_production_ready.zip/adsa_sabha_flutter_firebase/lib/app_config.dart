class AppConfig {
  static const appName = 'عدسة سبها';
  static const currency = 'د.ل';
}
