class UserProfile {
  final String uid;
  final String name;
  final String email;
  final String role;

  const UserProfile({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
  });

  bool get isAdmin => role == 'admin';

  factory UserProfile.fromMap(String uid, Map<String, dynamic> data) {
    return UserProfile(
      uid: uid,
      name: (data['name'] ?? '') as String,
      email: (data['email'] ?? '') as String,
      role: (data['role'] ?? 'user') as String,
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'email': email,
        'role': role,
      };
}

class AdItem {
  final String id;
  final String title;
  final String type;
  final double price;
  final String unit;
  final String location;
  final String imageUrl;
  final bool active;

  const AdItem({
    required this.id,
    required this.title,
    required this.type,
    required this.price,
    required this.unit,
    required this.location,
    required this.imageUrl,
    required this.active,
  });

  factory AdItem.fromMap(String id, Map<String, dynamic> d) => AdItem(
        id: id,
        title: (d['title'] ?? '') as String,
        type: (d['type'] ?? '') as String,
        price: ((d['price'] ?? 0) as num).toDouble(),
        unit: (d['unit'] ?? 'يوم') as String,
        location: (d['location'] ?? 'سبها') as String,
        imageUrl: (d['imageUrl'] ?? '') as String,
        active: (d['active'] ?? true) as bool,
      );

  Map<String, dynamic> toMap() => {
        'title': title,
        'type': type,
        'price': price,
        'unit': unit,
        'location': location,
        'imageUrl': imageUrl,
        'active': active,
        'updatedAt': DateTime.now().toUtc(),
      };
}

class OfferItem {
  final String id;
  final String title;
  final String details;
  final int discount;
  final bool active;

  const OfferItem({
    required this.id,
    required this.title,
    required this.details,
    required this.discount,
    required this.active,
  });

  factory OfferItem.fromMap(String id, Map<String, dynamic> d) => OfferItem(
        id: id,
        title: (d['title'] ?? '') as String,
        details: (d['details'] ?? '') as String,
        discount: ((d['discount'] ?? 0) as num).toInt(),
        active: (d['active'] ?? true) as bool,
      );

  Map<String, dynamic> toMap() => {
        'title': title,
        'details': details,
        'discount': discount,
        'active': active,
        'updatedAt': DateTime.now().toUtc(),
      };
}

class BookingItem {
  final String id;
  final String userId;
  final String adId;
  final String adTitle;
  final DateTime startDate;
  final DateTime endDate;
  final int days;
  final double total;
  final String paymentMethod;
  final String status;

  const BookingItem({
    required this.id,
    required this.userId,
    required this.adId,
    required this.adTitle,
    required this.startDate,
    required this.endDate,
    required this.days,
    required this.total,
    required this.paymentMethod,
    required this.status,
  });

  Map<String, dynamic> toMap() => {
        'userId': userId,
        'adId': adId,
        'adTitle': adTitle,
        'startDate': startDate.toUtc(),
        'endDate': endDate.toUtc(),
        'days': days,
        'total': total,
        'paymentMethod': paymentMethod,
        'status': status,
        'createdAt': DateTime.now().toUtc(),
      };

  factory BookingItem.fromMap(String id, Map<String, dynamic> d) {
    return BookingItem(
      id: id,
      userId: d['userId'] ?? '',
      adId: d['adId'] ?? '',
      adTitle: d['adTitle'] ?? '',
      startDate: (d['startDate'] as dynamic).toDate(),
      endDate: (d['endDate'] as dynamic).toDate(),
      days: ((d['days'] ?? 1) as num).toInt(),
      total: ((d['total'] ?? 0) as num).toDouble(),
      paymentMethod: d['paymentMethod'] ?? 'cash',
      status: d['status'] ?? 'pending',
    );
  }
}
