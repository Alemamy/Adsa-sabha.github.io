import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Firebase configuration for the production Android app.
/// Values are generated from the Firebase Android configuration supplied for
/// the project `adsa-sabha`.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (defaultTargetPlatform == TargetPlatform.android) {
      return android;
    }
    throw UnsupportedError(
      'Firebase is configured for Android in this release.',
    );
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBzn8KUugDwXtQE0qxQCmrOIXAzl3cLr80',
    appId: '1:353210712869:android:5fdc6d937ddb401ab610cc',
    messagingSenderId: '353210712869',
    projectId: 'adsa-sabha',
    storageBucket: 'adsa-sabha.firebasestorage.app',
  );
}
